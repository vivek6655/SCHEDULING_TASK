package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class Task {
	
	@Bean
	   public RestTemplate getRestTemplate() {
	      return new RestTemplate();
	   }
	
	
	@Scheduled(fixedDelay  = 5000)
	public void getData() {
		ResponseEntity<String> datas=getRestTemplate().getForEntity("https://dummyjson.com/users/1", String.class);
		String data=datas.getBody();
		System.out.println(data);
	}


	
//	int i=1;
//	@Scheduled(fixedRate = 5000)
//	//Scheduled a task every 5 second 
//	public void task() {
//		
//		System.out.println("Clean Temp File : "+i);
//		i++;
//	
//	}
	
//	@Scheduled(fixedDelay  = 5000)
//	public void taskss() {
//		
//		System.out.println("Clean Temp File : "+i);
//		i++;
//	
//	}
	
//	@Scheduled(cron = "0 0 12 * * ?")
//	//Second Minute Hour DayOfMonth Month  DayOfWeek
//	// Every Day of 12PM will execute
//	// * -- every 
//	public void tasks() {
//		
//		System.out.println("Clean Temp File : "+i);
//		i++;
//		
//	}

}
